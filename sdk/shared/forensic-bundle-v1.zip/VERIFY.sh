#!/bin/sh
set -eu
check() {
  file=$1
  expected=$2
  actual=$(openssl dgst -sha256 -r -- "$file" | awk '{print $1}')
  if [ "$actual" != "$expected" ]; then
    echo "FAIL $file expected=$expected actual=$actual" >&2
    exit 1
  fi
  echo "OK   $file $actual"
}
check 'audit_certificate.pdf' '1647dd1a8d698d8003ee3728f6ef0096f5112247316acc2788be9be3ffb68c6f'
check 'ledger_slice.cbor' 'e49139cdd294f6b5f679d09b0d5318c75b92b0ecdbedae44e12499229e31ed55'
check 'manifest.json' '0c55e6de07f6d7d36418819290241dc5830a44ffcc31fd7afe41f0c927ebbeb6'
check 'manifest.json.sig' 'f6fa2cde6850e09573d4fb834e3e668defb390e80f4d32bc42b66e044c334fe4'
check 'merkle_proof.json' '9f9e0e195e4e1ea542f576ee15dbe8ec5ffe8c3d09185a85d2ebd73226f0d455'

# ── Manifest signature ────────────────────────────────────────────────────
# The digests above are only as trustworthy as this script, and this script
# travels inside the archive it checks. Anyone who can rewrite a record can
# rewrite the digest next to it and this line with it. The signature below is
# what breaks that circularity -- but ONLY against a public key you already
# had. A key read out of this same archive proves nothing, so there is no
# embedded copy to accidentally trust.
if [ -n "${AEGIS_BUNDLE_PUBKEY:-}" ]; then
  if openssl pkeyutl -verify -pubin -inkey "$AEGIS_BUNDLE_PUBKEY" \
       -rawin -in manifest.json -sigfile manifest.json.sig >/dev/null 2>&1; then
    echo "OK   manifest.json signature verifies against $AEGIS_BUNDLE_PUBKEY"
  else
    echo "INVALID SIGNATURE: MANIFEST TAMPERED (or wrong key)" >&2
    exit 1
  fi
else
  echo "SKIP manifest.json signature: set AEGIS_BUNDLE_PUBKEY to the operator's" >&2
  echo "     Ed25519 public key, obtained OUT OF BAND, to authenticate this bundle." >&2
  echo "     Without it the checks above detect corruption, not tampering." >&2
fi

echo "Embedded file-byte SHA-256 values match this unauthenticated script."
echo "This does not authenticate the script or archive and does not verify canonical encodings, MMR proofs, or a trusted root."
